
/* an-ER-keyart-scale-in:38c5e900-def1-4531-8297-31e6eaa2b7e7.js, VERSION: 5.0.0, Published: 2019/08/09 11:41:03 $*/
// GENERIC SOURCE TRACKER: an-ER-fade-in
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
	"id": "38c5e900-def1-4531-8297-31e6eaa2b7e7",
	"name": "an-ER-background-scale-in",
	"description": "Background scale in then endframe elements fade in",
	"type": "animations",
	"context": "Default",
	"state": "published",
	"updated": 1551293070825,
	"full_name": "NetflixDev/an-ER-background-scale-in",
	"html_url": "https://github.com/NetflixDev/an-ER-background-scale-in",
	"username": "GitHub",
	"version": "5.0.0",
	"minimum": "3.0.0"
}
