
/* an-ER-making-a-murderer:38c5e900-def1-4531-8297-31e6eaa2b7e7.js, VERSION: 5.0.0, Published: 2019/03/28 15:16:52 $*/
// GENERIC SOURCE TRACKER: an-ER-fade-in
if (typeof module === 'undefined') {
	module = {};
}
// prettier-ignore
module.exports = {
	"id": "38c5e900-def1-4531-8297-31e6eaa2b7e7",
	"name": "an-ER-making-a-murderer",
	"description": "Keyart scale in then endframe elements fade in",
	"type": "animations",
	"context": "Default",
	"state": "published",
	"updated": 1551293070825,
	"full_name": "NetflixDev/an-ER-making-a-murderer",
	"html_url": "https://github.com/NetflixDev/an-ER-making-a-murderer",
	"username": "GitHub",
	"version": "5.0.0",
	"minimum": "3.0.0"
}